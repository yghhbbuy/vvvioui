<?php $configs = '
{
    "admin": "123123123",
    "timezone": "8"
}
';